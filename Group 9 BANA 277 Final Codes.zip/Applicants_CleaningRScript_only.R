# install.packages("mltools")
$ install.packages("data.table")
 library(mltools)
 library(data.table)
 library(dplyr)
 library(plyr)
setwd("~/Desktop/Winter 2021/Bana 277/project")
#####DATA CLEANING#######

data = read.csv("Merged_SMPAPPLICANTS.csv")
##make an ID Column
data$ID = seq(1, nrow(data))
data <- data %>%
  select(ID, everything())

#delete columns that we don't need
data = subset(data, select = -c(Start.Term.and.Year, Pardot.First.Referrer))

##only want SMP
smp_programs = c("Master of Finance", "Master of Innovation and Entrepreneurship",
                "Master of Science in Business Analytics", "Master of Professional Accountancy")
data<- data %>% filter( Programs %in% smp_programs)



data$Programs = as.factor(data$Programs)
data$Lead.Source = as.factor(data$Lead.Source)
data$Residency.Status = as.factor(data$Residency.Status)
#> sum(smp_applicants$Pardot.First.Referrer == "")
#[1] 3480
#> sum(smp_applicants$Pardot.First.Activity == "")
#[1] 2800
#one hot encoding for dummy variables
data<- one_hot(as.data.table(data))

colnames(data) = c("ID", "Programs_fin", "Programs_mie", "Programs_mpa", 
                         "Programs_msba", "app_submit_date", "Residency_citizen",
                         "Residency_intl", "first_activity", "Lead_gmass", "Lead_gmat",
                         "Lead_gradfair", "Lead_grescoresender", "Lead_hobsons",
                         "Lead_internalinquiryform", "Lead_onlineapp",
                         "Lead_eventreg", "Lead_qualifiedlistupload",
                         "Lead_unqualifiedlistupload", "Lead_webinquiryform", 
                         "Lead_worldmbatour", "Lead_youvisit")
##there are 2k rows where first_activity is missing. delete those 
data = subset(data, first_activity != "")

##check sum of all dummy variables. Results show that we should delete the Lead Sources named
#youvisit(4), unqualifiedlistupload(1),qualifiedlistupload(2) because these are too low in numbers.
#may have to think about also deleting internalinquiryform(8), worldmbatour(6) and hobsons(11)
#due to low numbers 
numcolwise(sum)(data)
#Note: At the ending step, we will subset for only those rows that we need


##deal with the date columns
library(stringr)
data$first_activity = substr(data$first_activity, 1, nchar(data$first_activity)-5)
data$first_activity = str_trim(data$first_activity)
#data$first_activity = as.Date(data$first_activity, "%m%d%Y")

data$first_activity = as.POSIXct(data$first_activity,format='%m/%d/%y')
data$app_submit_date = as.POSIXct(data$app_submit_date,format='%m/%d/%y')

data$time_elapsed = floor(difftime(data$app_submit_date, data$first_activity, units = "days"))
data$time_elapsed_since_app_window_opens =  floor(difftime(data$app_submit_date, c("2018-09-01"), units = "days"))

##subset out the rows
#data = subset(data, select = -c(Lead_unqualifiedlistupload, Lead_qualifiedlistupload, Lead_youvisit))

#write to csv
write.csv(data, file = "smp_applicants_datacleaned2.csv")


####START MODELING BELOW